<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Test;

class TestController extends Controller
{
    // public function read(){
    //     //Чтобы читать один элемент
    //     // $test = Test::find(1);
    //     // // dd($test);  
    //     // dd($test->title);  
    //     // echo $test['title'];

    //     //Чтобы читать все элементы
    //     $tests = Test::all();
    //     foreach($tests as $test){
    //         dump($test->title);
    //     }
    //     dd('end');

    //     //Чтобы читать элементы по условиям
    //     // $tests = Test::where('is_published', 1)->get();
    //     // foreach($tests as $test){
    //     //     dump($test->title);
    //     // }
    //     // dd('end');
    // }


    public function create(){
        $postsArr = [
            [
                'title'=> 'Title written by code',
                'content'=> 'Cintent written by code',
                'image'=> 'image 4 by from code',
                'is_published'=> '1',
            ],
            [
                'title'=> 'Another title written by code',
                'content'=> 'Another cintent written by code',
                'image'=> 'Anothert image 4 by from code',
                'is_published'=> '1',
            ]
            ];

            Test::create([
                'title'=> 'Another title written by code',
                'content'=> 'Another cintent written by code',
                'image'=> 'Anothert image 4 by from code',
                'is_published'=> '1',
            ]);

            dd('created');
    }

}
